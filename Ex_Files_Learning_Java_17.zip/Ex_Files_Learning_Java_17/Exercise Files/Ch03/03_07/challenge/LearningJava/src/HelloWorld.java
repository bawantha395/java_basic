public class HelloWorld {

    public static void main(String args[]) {
        String question = "";
        String choiceOne = "";
        String choiceTwo = "";
        String choiceThree = "";

        String correctAnswer = choiceTwo;

        // TODO: Write a print statement asking the question
        // TODO: Write a print statement giving the answer choices

        // TODO: Have the user input an answer
        // TODO: Retrieve the user's input

        // TODO: If the user's input matches the correctAnswer...
        // TODO: then the user is correct and we want to print out a
        //  congrats message to the user.

        // TODO: If the user's input does not match the correctAnswer...
        // TODO: then the user is incorrect and we want to print out a
        //  message saying that the user is incorrect as well as what the
        //  correct choice was.

    }
}
