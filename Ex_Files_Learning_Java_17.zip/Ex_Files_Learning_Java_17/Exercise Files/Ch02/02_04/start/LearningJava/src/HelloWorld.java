public class HelloWorld {

    public static void main(String[] args) {
        int studentAge = 15;
        double studentGPA = 3.45;
        boolean hasPerfectAttendance = true;

        char studentFirstInitial = 'K';
        char studentLastInitial = 'H';
        String studentFirstName = "Kayla";
        String studentLastName = "Harley";

        System.out.println(studentAge);
        System.out.println(studentGPA);
        System.out.println(studentFirstInitial);
        System.out.println(studentLastInitial);

        System.out.println(hasPerfectAttendance);
        System.out.println(studentFirstName);
        System.out.println(studentLastName);

    }
}
